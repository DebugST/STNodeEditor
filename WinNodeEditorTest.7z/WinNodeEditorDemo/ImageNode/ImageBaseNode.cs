﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ST.Library.UI.NodeEditor;
using System.Drawing;

namespace WinNodeEditorDemo.ImageNode
{
    public abstract class ImageBaseNode : STNode
    {
        protected Image m_img_draw;
        protected STNodeOption m_op_img_out;

        protected override void OnCreate() {
            base.OnCreate();
            m_op_img_out = this.OutputOptions.Add("", typeof(Image), false);
            this.AutoSize = false;
            //this.Size = new Size(320,240);
            this.Width = 160;
            this.Height = 120;
            this.TitleColor = Color.DarkCyan;
        }

        protected override void OnOwnerChanged() {
            base.OnOwnerChanged();
            if (this.Owner == null) return;
            this.Owner.SetTypeColor(typeof(Image), Color.DarkCyan);
        }
    }
}
