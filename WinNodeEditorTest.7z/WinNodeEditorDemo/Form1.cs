﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WinNodeEditorDemo
{
    public partial class Form1 : Form
    {
        public Form1() {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e) {
            base.OnLoad(e);
            stNodePropertyGrid1.Text = "Node_Property";
            stNodeTreeView1.AddSTNodeFromFile(Application.ExecutablePath);
            stNodeEditor1.LoadAssembly(Application.ExecutablePath);

            stNodeEditor1.SelectedChanged += (s, ea) => stNodePropertyGrid1.SetSTNode(stNodeEditor1.ActiveNode);
            stNodeEditor1.OptionConnected += (s, ea) => stNodeEditor1.ShowAlert(ea.Status.ToString(), Color.White, Color.Green);
        }

        private void Form1_Load(object sender, EventArgs e) {
            //int nLines = 0;
            //foreach (var v in Directory.GetFiles("../../../", "*.cs", SearchOption.AllDirectories)) {
            //    nLines += File.ReadAllLines(v).Length;
            //}
            //try {
            //    new Blender.BlenderMixColorNode();
            //} catch (Exception ex) {
            //    MessageBox.Show(ex.Message);
            //}
            //MessageBox.Show(nLines.ToString());
        }

        private void btn_open_Click(object sender, EventArgs e) {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "*.stn|*.stn";
            if (ofd.ShowDialog() != DialogResult.OK) return;
            stNodeEditor1.Nodes.Clear();
            stNodeEditor1.LoadCanvas(ofd.FileName);
        }

        private void btn_save_Click(object sender, EventArgs e) {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "*.stn|*.stn";
            if (sfd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
            stNodeEditor1.SaveCanvas(sfd.FileName);
        }
    }
}
