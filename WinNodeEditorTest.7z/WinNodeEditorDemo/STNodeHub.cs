﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ST.Library.UI.NodeEditor;

namespace WinNodeEditorDemo
{
    [STNode("/", "Crystal_lz", "2212233137@qq.com", "st233.com", "This is Hub")]
    public class STNodeHubSingle : STNodeHub
    {
        public STNodeHubSingle()
            : base(true) {
            this.Title = "单连HUB";
        }
    }

    [STNode("/", "Crystal_lz", "2212233137@qq.com", "st233.com", "This is Hub")]
    public class STNodeHubMulti : STNodeHub
    {
        public STNodeHubMulti()
            : base(false) {
            this.Title = "多连HUB";
        }
    }
}
