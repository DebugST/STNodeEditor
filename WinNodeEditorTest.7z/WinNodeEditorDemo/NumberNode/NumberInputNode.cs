﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ST.Library.UI.NodeEditor;
using System.Drawing;

namespace WinNodeEditorDemo.NumberNode
{
    [STNode("/Number/","Crystal_lz","2212233137@qq.com","www.st233.com","Number input node")]
    public class NumberInputNode : NumberNode
    {
        private int _Number;
        [STNodeProperty("Input","this is input number")]
        public int Number {
            get { return _Number; }
            set { 
                _Number = value;
                m_op_number.TransferData(value);
                this.Invalidate();
            }
        }

        private STNodeOption m_op_number;
        private StringFormat m_sf = new StringFormat();

        protected override void OnCreate() {
            base.OnCreate();
            this.Title = "NumberInput";
            m_op_number = new STNodeOption("", typeof(int), false);
            this.OutputOptions.Add(m_op_number);
            m_sf = new StringFormat();
            m_sf.LineAlignment = StringAlignment.Center;
            m_sf.Alignment = StringAlignment.Far;
        }

        protected override void OnDrawOptionText(DrawingTools dt, STNodeOption op) {
            base.OnDrawOptionText(dt, op);
            dt.Graphics.DrawString(this._Number.ToString(), this.Font, Brushes.White, op.TextRectangle, m_sf);
        }
    }
}
