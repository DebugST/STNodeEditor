﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ST.Library.UI.NodeEditor;
using System.Drawing;

namespace WinNodeEditorDemo.NumberNode
{
    public abstract class NumberNode : STNode
    {
        protected override void OnCreate() {
            base.OnCreate();
            this.TitleColor = Color.CornflowerBlue;
        }
        protected override void OnOwnerChanged() {
            base.OnOwnerChanged();
            if (this.Owner != null) this.Owner.SetTypeColor(typeof(int), Color.CornflowerBlue);
        }
    }
}
